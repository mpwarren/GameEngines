#include "Platform.h"
#include <iostream>

Platform::Platform(sf::Vector2f size, sf::Vector2f position, std::string texturePath) : CollidableObject(size, position, texturePath){
}

